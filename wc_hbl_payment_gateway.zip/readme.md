

**== Installation ==**
1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the \'Plugins\' screen in WordPress
3. Create a page named Payment add `[hbl_2c2p_custom_payment]`. Save.
4. Use the Settings->Plugin Name screen to configure the plugin enter the below data for setting page.
	1. Enable/Status -> Enable/Disable the plugin. 
	2. Title      	 -> Display title for HBL payment getaway.
	3. Description   -> Display the description when you select payment type as Credit Card.
	* Merchant ID   -> Merchant ID provided by HBL
	* Secrect Key   -> Secret Key for authentication
	* Mode		-> Select mode - Test: [HBL don't have test mode ], Live: Production
	* Payment Page	-> Select payment page that you created in step 3
	
	
**==TODO==**
1. Refactor code
    * Remove unwanted code
    * Style in css file

